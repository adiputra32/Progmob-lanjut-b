<?php
 
	require_once 'include/DB_Functions.php';
	$db = new DB_Functions();
	 
	// json response array
	$response = array("error" => "false");
	 
	if (isset($_POST['id_sewa']) && isset($_FILES['ppimage'])) {
		$id_sewa = $_POST['id_sewa'];
		$ppimage = $_FILES['ppimage']["tmp_name"];
		$ppimage_name = basename($_FILES["ppimage"]["name"]);
	 
		$motor = $db->updatePembayaran($id_sewa, $ppimage, $ppimage_name);
	 
		if ($motor != false) {
			$response["error"] = "false";
			echo json_encode($response);
		} else {
			$response["error"] = "true";
			$response["error_msg"] = "Something error.";
			echo json_encode($response);
		}
	} else {
		$response["error"] = "true";
		$response["error_msg"] = "Parameter kurang";
		echo json_encode($response);
	}
?>