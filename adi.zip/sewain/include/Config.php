<?php
// 	define("DB_HOST", "localhost");
// 	define("DB_USER", "id11594476_sewainbali");
// 	define("DB_PASSWORD", "sewainbali");
// 	define("DB_DATABASE", "id11594476_sewain");
// 	define("DB_HOST", "localhost");
// 	define("DB_USER", "root");
// 	define("DB_PASSWORD", "");
// 	define("DB_DATABASE", "db_sewain_bali");
    define("DB_HOST", "localhost");
	define("DB_USER", "id11594476_sewain_bali");
	define("DB_PASSWORD", "sewainbali123");
	define("DB_DATABASE", "id11594476_sewain_bali_db");
?>